package com.test.exercises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercisesApplicationTests {

	@Test
	void contextLoads() {
	}

}
