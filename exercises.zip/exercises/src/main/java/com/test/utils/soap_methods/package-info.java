//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.3.0 
// Consulte <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2022.07.10 às 02:13:59 PM GMT-03:00 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.oorsprong.org/websamples.countryinfo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.test.utils.soap_methods;
