package com.test.exercises.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.exercises.soap_configuration.CountryClient;
import com.test.utils.soap_methods.FullCountryInfoAllCountriesResponse;
import com.test.utils.soap_methods.TCountryInfo;

@Service
public class CountryService {
    @Autowired CountryClient client;

    public String getCurrencyISOCode(String countryName){
        FullCountryInfoAllCountriesResponse res = client.getCountries();
		List<TCountryInfo> list = res.getFullCountryInfoAllCountriesResult().getTCountryInfo();
		Optional<TCountryInfo> find = list.stream().filter(l -> l.getSName().equals(countryName)).findFirst();
        return find.get().getSCurrencyISOCode();
    }

}
