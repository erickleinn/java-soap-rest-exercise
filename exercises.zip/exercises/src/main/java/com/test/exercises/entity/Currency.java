package com.test.exercises.entity;

import lombok.Data;

@Data
public class Currency {
    private String isoCode;
}
