package com.test.exercises.soap_controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.test.exercises.services.CountryService;
import com.test.exercises.services.PrimeNumbersService;
import com.test.utils.soap_test.Currency;
import com.test.utils.soap_test.GetCountryCurrencyRequest;
import com.test.utils.soap_test.GetCountryCurrencyResponse;
import com.test.utils.soap_test.GetPrimeNumberRequest;
import com.test.utils.soap_test.GetPrimeNumberResponse;


@Endpoint
public class SoapEndpoint {

    private static final String NAMESPACE_URI = "http://com/test/utils/soap_test";

    @Autowired
    CountryService countryService;

    @Autowired
    PrimeNumbersService primeNumbersService;

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCountryCurrencyRequest")
    @ResponsePayload
    public GetCountryCurrencyResponse getCountryCurrency(@RequestPayload GetCountryCurrencyRequest request) {
        GetCountryCurrencyResponse response = new GetCountryCurrencyResponse();
        Currency currency = new Currency();
        String currencyISOCode = countryService.getCurrencyISOCode(request.getCountryName());
        currency.setCurrencyISOCode(currencyISOCode != null && !currencyISOCode.isBlank() ? currencyISOCode : "");
        response.setCurrency(currency);
        return response;

    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getPrimeNumberRequest")
    @ResponsePayload
    public GetPrimeNumberResponse findSumPrimeNumbers(@RequestPayload GetPrimeNumberRequest request) {
        GetPrimeNumberResponse response = new GetPrimeNumberResponse();
        response.setResult(primeNumbersService.findAndSumPrimes(request.getNumber()));
        return response;
    }
}